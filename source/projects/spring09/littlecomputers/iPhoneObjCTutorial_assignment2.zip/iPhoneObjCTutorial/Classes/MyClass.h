//
//  MyClass.h
//  iPhoneObjCTutorial
//
//  Created by Steven Lehrburger on 2/14/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyClass : NSObject {
	float myFloat;
}

- (void) hello;
- (void) setMyFloat:(float)val;
- (float)myFloat;

@end

//
//  MyClass.m
//  iPhoneObjCTutorial
//
//  Created by Steven Lehrburger on 2/14/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyClass.h"


@implementation MyClass
- (id) init
{
	self = [super init];
	if(self != nil)
	{
		myFloat = 5.0;
	}
	return self;
}

- (void) hello
{
	NSLog(@"Hello, I'm your first iPhone program!");
}

- (void) setMyFloat:(float)val
{
	myFloat = val;
}

- (float)myFloat
{
	return myFloat;
}

- (void) dealloc
{
	// release any retained objects here.
	[super dealloc];
}


@end

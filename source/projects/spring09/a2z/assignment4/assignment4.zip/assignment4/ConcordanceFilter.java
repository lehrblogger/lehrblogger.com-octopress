import java.util.HashMap;
import java.util.Comparator;
import java.util.Collections;
import java.util.ArrayList;
import com.decontextualize.a2z.TextFilter;

public class ConcordanceFilter extends TextFilter {

  public static void main(String[] args) {
    ConcordanceFilter cf = new ConcordanceFilter();
    cf.setSearchWord(args[0]);
    cf.run();
  }

  private Concordance concord = new Concordance();
  private String searchWord;

  public void setSearchWord(String searchWord_) {
    searchWord = searchWord_;
  }

  public void eachLine(String line) {
    concord.feedLine(line);
  }

  public void end() {
    if (concord.containsWord(searchWord)) {
      WordContext w = concord.getWord(searchWord);
      ArrayList<String> contexts = w.getContexts();
      println("Contexts, unsorted");
      for (String context: contexts) {
        println("  " + context);
      }
      
      println("Contexts, sorted alphabetically");
      Comparator<String> alphaComp = new AlphabeticComparator();
      Collections.sort(contexts, alphaComp);
      for (String context: contexts) {
        println("  " + context);
      }
      
      println("Contexts, sorted by word count");
      Comparator<String> wcComp = new WordCountComparator();
      Collections.sort(contexts, wcComp);
      for (String context: contexts) {
        println("  " + context);
      }
    }  
  }
}
import java.util.ArrayList;

public class WordContext {
  private ArrayList<String> contexts;
  private String word;

  public WordContext(String word_) {
    word = word_;
    contexts = new ArrayList<String>();
  }

  public void addContext(String context) {
    contexts.add(context);
  }

  public ArrayList<String> getContexts() {
    return contexts;
  }

  public String getWord() {
    return word;
  }

}

class AlphabeticComparator implements java.util.Comparator<String> {
	public int compare(String one, String two) {
	
		int minLength;
		if (one.length() > two.length()) { minLength = two.length(); }	
		else 					         { minLength = one.length(); }
		
		for (int i = 0; i < minLength; i++) {
			if (one.charAt(i) == two.charAt(i)) {
				// go on to next char
			}
			else if (one.charAt(i) < two.charAt(i)) {
				return -1;
			} else {
				return 1;
			}
		}
		
		return 0;
	}
}
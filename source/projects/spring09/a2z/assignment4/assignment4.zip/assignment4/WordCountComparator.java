class WordCountComparator implements java.util.Comparator<String> {
	public int compare(String one, String two) {
	
		return (one.split("\\W+").length - two.split("\\W+").length);
	}
}
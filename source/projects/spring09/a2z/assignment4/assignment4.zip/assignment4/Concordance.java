import java.util.HashMap;
import java.util.ArrayList;

public class Concordance {

  protected HashMap<String, WordContext> concordance;

  public Concordance() {
    concordance = new HashMap<String, WordContext>();
  }

  public void feedLine(String line) {
    String[] tokens = line.split("\\W+");
    for (String token: tokens) {
      if (concordance.containsKey(token)) {
        WordContext w = concordance.get(token);
        w.addContext(line);
      }
      else {
        WordContext w = new WordContext(token);
        w.addContext(line);
        concordance.put(token, w);
      }
    }
  }

  public boolean containsWord(String token) {
    return concordance.containsKey(token);
  }

  public WordContext getWord(String token) {
    return concordance.get(token);
  }

  public ArrayList<WordContext> getAllWords() {
    return new ArrayList<WordContext>(concordance.values());
  }

}

import java.util.HashMap;
import com.decontextualize.a2z.TextFilter;

public class WordCount extends TextFilter {
  public static void main(String[] args) {
    new WordCount().run();
  }

  HashMap<String, Integer> words = new HashMap<String, Integer>();

  public void eachLine(String line) {
    String[] tokens = line.split("\\W+");
    for (String t: tokens) {
      if (words.containsKey(t)) {
        int currentCount = words.get(t);
        words.put(t, currentCount + 1);
      }
      else {
        words.put(t, 1);
      }
    }
  }

  public void end() {
    for (String key: words.keySet()) {
      println(key + ":" + words.get(key));
    }
  }

}

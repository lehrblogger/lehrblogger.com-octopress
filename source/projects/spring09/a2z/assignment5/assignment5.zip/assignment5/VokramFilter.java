import com.decontextualize.a2z.TextFilter;

public class VokramFilter extends TextFilter {

  public static void main(String[] args) {
    new VokramFilter().run();
  }

  Vokram vokr = new Vokram(4, 100);

  public void eachLine(String line) {
    vokr.feedLine(line);
  }

  public void end() {
    vokr.dump();
    println(vokr.generateLine());
  }

}


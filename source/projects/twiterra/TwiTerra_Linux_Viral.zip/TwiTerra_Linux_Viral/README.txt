The instructions for a Windows computer are as follows - perhaps they will be useful.

For this to run, you will need to put two sets of files in places that Java can find them. Open C:\Program Files\Java, and open the folder for the most recent version (the highest number). Move the two files from this 'lib\jars' folder into the 'lib\ext' folder of that Java folder. Move all of the files from this 'lib' folder into the 'bin' folder of that Java folder. Then double click the 'TwiTerra_Windows' file, and wait a minute or so for it to launch.

Please contact me if you have any questions.

Thanks,
Steven Lehrburger
lehrburger(at)gmail(dot)com
http://twiterra.com
httpL//lehrblogger.com